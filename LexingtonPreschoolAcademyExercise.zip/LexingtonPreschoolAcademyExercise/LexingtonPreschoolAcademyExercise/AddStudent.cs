﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LexingtonPreschoolAcademyExercise
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private void savesStudent_Click(object sender, EventArgs e)
        {
            //This is attached to the save button; the text boxes are the first and last name.
            var fname = FirstNameBox.Text;
            var lname = LastNameBox.Text;

            //When the program is finished, it will give the user this message box.
            string message = "";
            string caption = "";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            DialogResult result;

            //The first name cannot be blank or null; it will not proceed if it is.
            if (fname == null || fname == "")
            {
                caption = "Warning";
                message = "First name cannot be blank.";
                result = MessageBox.Show(message, caption, buttons);
            }
            else if (lname == null || lname == "")
            {
                caption = "Warning";
                message = "Last name cannot be blank.";
                result = MessageBox.Show(message, caption, buttons);
            }
            else
            {
                //Creates new student in Students with FirstName and LastName
                //-1 is set due to default value; will also appear if it cannot find something

                SqlConnection sc = new SqlConnection();
                SqlCommand com = new SqlCommand();
                int queryResultStudent = -1;
                int queryResultClass = -1;

                //Connection string is based off user profile
                string userProfile = Environment.GetEnvironmentVariable("USERPROFILE");
                string connectionString = ("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + userProfile + "\\source\\repos\\LexingtonPreschoolAcademyExercise\\LexingtonPreschoolAcademyExercise\\StudentData.mdf;Integrated Security=True");
                
                using (sc = new SqlConnection(connectionString))
                {
                    sc.Open();

                    //This is the SQL command that actually inserts the student.
                    using (com = new SqlCommand("InsertStudent", sc))
                    {
                        com.CommandType = System.Data.CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("@FirstName", fname);
                        com.Parameters.AddWithValue("@LastName", lname);       
                        com.ExecuteNonQuery();
                    }

                    //The StudentId increments from when table was created
                    //It takes the latest StudentID just in case two students have the same name.
                    using (com = new SqlCommand("GetLatestStudentId", sc))
                    {
                        com.CommandType = System.Data.CommandType.StoredProcedure;
                        queryResultStudent = (int)com.ExecuteScalar();
                    }

                    //If something went wrong
                    if (queryResultStudent != -1)
                    {
                        var sText = ClassesBox.SelectedItems;
                        foreach (var s in sText)
                        {
                            //Finds the id of each class.
                            queryResultClass = -1;
                            using (com = new SqlCommand("GetClassId", sc))
                            {
                                com.CommandType = System.Data.CommandType.StoredProcedure;
                                com.Parameters.AddWithValue("@ClassName", s);
                                queryResultClass = (int)com.ExecuteScalar();
                            }

                            //Inserts the ClassIds for each StudentId.
                            //If for whatever reason it cannot find a class, it will not save the data for that specific class and move onto the next.
                            using (com = new SqlCommand("SetStudentClasses", sc))
                            {
                                com.CommandType = System.Data.CommandType.StoredProcedure;
                                if (queryResultClass != -1)
                                {
                                    com.Parameters.AddWithValue("@StudentId", queryResultStudent);
                                    com.Parameters.AddWithValue("@ClassId", queryResultClass);
                                    com.ExecuteNonQuery();
                                }
                            }
                        }
                        caption = "Success!";
                        message = "Data has been saved.";
                        sc.Close();
                    }
                    else
                    {
                        caption = "Warning";
                        message = "There was an issue with saving the data.";
                    }
                }
                result = MessageBox.Show(message, caption, buttons);
                this.Close();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            //Closes the window if the cancel button is pressed.
            this.Close();
        }
    }
}
