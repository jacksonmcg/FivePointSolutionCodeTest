﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LexingtonPreschoolAcademyExercise
{
    public partial class StudentList : Form
    {
        public StudentList()
        {
            //Initalizes data when program begins
            InitializeComponent();
            LoadStudentData();

            //Ensures data is reloaded if page goes back into focus
            this.Activated += new EventHandler(StudentList_Activated);
        }

        private void AddStudent_Click(object sender, EventArgs e)
        {
            //Attached to add button; creates add student form when clicked.
            var studentForm = new AddStudent();
            studentForm.Show();
        }

        private void LoadStudentData()
        {
            //Creates connectionstring based off user profile
            string userProfile = Environment.GetEnvironmentVariable("USERPROFILE");
            string connectionString = ("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + userProfile + "\\source\\repos\\LexingtonPreschoolAcademyExercise\\LexingtonPreschoolAcademyExercise\\StudentData.mdf;Integrated Security=True");

            //In order to refresh the data, we need a fresh SQL query. Refreshing bindings does not work.
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT FirstName, LastName FROM Students", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);

                dataGridView1.DataSource = dtbl;
            }
        }

        private void StudentList_Load(object sender, EventArgs e)
        {
            //Loads the database when loading program
            LoadStudentData();
        }

        private void StudentList_Activated(object sender, EventArgs e)
        {
            //Loads the database when programmed is focused
            LoadStudentData();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jackson McGregor\nCoding Project\n08/14/2024");
        }
    }
}