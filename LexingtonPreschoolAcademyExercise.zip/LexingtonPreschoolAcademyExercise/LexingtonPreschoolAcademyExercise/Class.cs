﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexingtonPreschoolAcademyExercise
{
    public class Class
    {
        private int? id;
        private string className;

        public Class(string className, int? id = null)
        {
            this.className = className;
            this.id = id;
        }

        public int? getId()
        {
            return this.id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public string getClassName()
        {
            return this.className;
        }

        public void setClassName(string name)
        {
            this.className = name;
        }

        public bool validId()
        {
            if (this.id == null || this.id <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
